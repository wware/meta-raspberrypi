void color_init(struct ida_image *img);
